#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_check1_clicked(bool checked)
{
    ui->widget1->setVisible(checked);
}

void MainWindow::on_check2_clicked(bool checked)
{
    ui->widget2->setVisible(checked);
}

void MainWindow::on_check3_clicked(bool checked)
{
    ui->widget3->setVisible(checked);
}
